<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'wwasse_confirmacaoassego');
define('DB_USER', 'wwasse_confir');
define('DB_PASS', '');  // ← COLOQUE A SENHA DO BANCO AQUI
define('SITE_NAME', 'ASSEGO Eventos');

date_default_timezone_set('America/Sao_Paulo');

function getConnection() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]);
    }
    return $pdo;
}

function clean_input($d) { return htmlspecialchars(stripslashes(trim($d))); }

function formatPhone($p) {
    $p = preg_replace('/[^0-9]/','',$p);
    if(strlen($p)==11) return preg_replace('/(\d{2})(\d{5})(\d{4})/','($1) $2-$3',$p);
    return preg_replace('/(\d{2})(\d{4})(\d{4})/','($1) $2-$3',$p);
}

function checkLogin() {
    if(session_status()===PHP_SESSION_NONE) session_start();
    if(!isset($_SESSION['logged_in'])||$_SESSION['logged_in']!==true){ header('Location: login.php'); exit(); }
}

function isAdmin() {
    if(session_status()===PHP_SESSION_NONE) session_start();
    return ($_SESSION['user_role']??'') === 'admin';
}

function getUserId() {
    if(session_status()===PHP_SESSION_NONE) session_start();
    return $_SESSION['user_id'] ?? 0;
}

function getUserName() {
    if(session_status()===PHP_SESSION_NONE) session_start();
    return $_SESSION['user_nome'] ?? 'Usuário';
}

function getEventosPermitidos($pdo) {
    $uid = getUserId();
    $role = $_SESSION['user_role'] ?? 'operador';
    if ($role === 'admin') {
        return $pdo->query("SELECT * FROM eventos WHERE ativo=1 ORDER BY data_inicio DESC")->fetchAll();
    }
    $s = $pdo->prepare("SELECT e.* FROM eventos e INNER JOIN usuario_eventos ue ON e.id=ue.evento_id WHERE ue.usuario_id=? AND e.ativo=1 ORDER BY e.data_inicio DESC");
    $s->execute([$uid]);
    return $s->fetchAll();
}

function temAcessoEvento($pdo, $eventoId) {
    if (isAdmin()) return true;
    $s = $pdo->prepare("SELECT COUNT(*) FROM usuario_eventos WHERE usuario_id=? AND evento_id=?");
    $s->execute([getUserId(), $eventoId]);
    return $s->fetchColumn() > 0;
}

function getEventoAtual($pdo) {
    if(session_status()===PHP_SESSION_NONE) session_start();
    $id = $_SESSION['evento_atual'] ?? null;
    if($id){ $s=$pdo->prepare("SELECT * FROM eventos WHERE id=? AND ativo=1"); $s->execute([$id]); return $s->fetch(); }
    return null;
}

function setEventoAtual($id) {
    if(session_status()===PHP_SESSION_NONE) session_start();
    $_SESSION['evento_atual'] = $id;
}
?>
