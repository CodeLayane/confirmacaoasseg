<?php
require_once 'layout.php';
if(!$evento_atual){header('Location: index.php');exit();}
$eid=$evento_atual['id'];
if(isset($_GET['aprovar'])){$pdo->prepare("UPDATE participantes SET aprovado=1 WHERE id=? AND evento_id=?")->execute([$_GET['aprovar'],$eid]);header("Location: solicitacoes.php?message=Aprovado!");exit();}
if(isset($_GET['rejeitar'])){$pdo->prepare("DELETE FROM participantes WHERE id=? AND evento_id=? AND aprovado=0")->execute([$_GET['rejeitar'],$eid]);header("Location: solicitacoes.php?message=Rejeitado.");exit();}
if(isset($_GET['aprovar_todos'])){$pdo->prepare("UPDATE participantes SET aprovado=1 WHERE evento_id=? AND aprovado=0")->execute([$eid]);header("Location: solicitacoes.php?message=Todos aprovados!");exit();}
$s=$pdo->prepare("SELECT * FROM participantes WHERE evento_id=? AND aprovado=0 ORDER BY created_at DESC");$s->execute([$eid]);$pendentes=$s->fetchAll();
$campos_extras=json_decode($evento_atual['campos_extras']??'[]',true)?:[];$message=$_GET['message']??'';
?>
<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Solicitações - ASSEGO</title><?php renderCSS();?></head><body>
<?php renderHeader('solicitacoes');?>
<?php if($message):?><div class="content-container"><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?=htmlspecialchars($message)?></div></div><?php endif;?>
<div class="page-header">
    <h1 class="page-title"><i class="fas fa-user-clock"></i> Solicitações (<?=count($pendentes)?>)<?php if($evento_atual):?> <small style="color:var(--gray);font-weight:400;font-size:14px">— <?=htmlspecialchars($evento_atual['nome'])?></small><?php endif;?></h1>
    <?php if(count($pendentes)>0):?><button onclick="Swal.fire({title:'Aprovar todos?',text:'<?=count($pendentes)?> cadastros',icon:'question',showCancelButton:true,confirmButtonText:'Aprovar Todos',confirmButtonColor:'#059669'}).then(r=>{if(r.isConfirmed)location='solicitacoes.php?aprovar_todos=1'})" class="btn btn-success"><i class="fas fa-check-double"></i> Aprovar Todos</button><?php endif;?>
</div>
<div class="content-container" style="padding-top:0">
<?php if(empty($pendentes)):?><div class="form-card text-center"><i class="fas fa-inbox" style="font-size:48px;color:#dbeafe;margin-bottom:16px"></i><p style="color:var(--gray)">Nenhuma solicitação pendente.</p></div>
<?php else:?><div style="display:grid;gap:12px">
<?php foreach($pendentes as $p):$extras=json_decode($p['campos_extras']??'{}',true)?:[];$sf=$pdo->prepare("SELECT dados FROM fotos WHERE participante_id=? LIMIT 1");$sf->execute([$p['id']]);$foto_p=$sf->fetchColumn();?>
<div class="form-card" style="display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap;padding:16px">
<div style="width:70px;height:70px;border-radius:12px;overflow:hidden;background:#e0f2fe;flex-shrink:0"><?php if($foto_p):?><img src="<?=$foto_p?>" style="width:100%;height:100%;object-fit:cover"><?php else:?><div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:24px"><i class="fas fa-user"></i></div><?php endif;?></div>
<div style="flex:1;min-width:200px">
<h4 style="color:var(--primary);margin-bottom:6px"><?=htmlspecialchars($p['nome'])?></h4>
<div style="display:flex;gap:12px;flex-wrap:wrap;font-size:13px;color:var(--gray);margin-bottom:6px">
<?php if($p['whatsapp']):?><span><i class="fab fa-whatsapp" style="color:#25d366"></i> <?=htmlspecialchars($p['whatsapp'])?></span><?php endif;?>
<?php if($p['instagram']):?><span><i class="fab fa-instagram" style="color:#e1306c"></i> @<?=htmlspecialchars(ltrim($p['instagram'],'@'))?></span><?php endif;?>
<?php if($p['cidade']):?><span><i class="fas fa-map-marker-alt"></i> <?=htmlspecialchars($p['cidade'].($p['estado']?' - '.$p['estado']:''))?></span><?php endif;?>
</div>
<?php if(!empty($extras)):?><div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px"><?php foreach($campos_extras as $ce):if(!empty($extras[$ce['nome']])):?><span style="background:#f0f9ff;border:1px solid #dbeafe;padding:2px 8px;border-radius:8px;font-size:11px"><strong><?=$ce['label']?>:</strong> <?=htmlspecialchars($extras[$ce['nome']])?></span><?php endif;endforeach;?></div><?php endif;?>
<span style="font-size:11px;color:#94a3b8"><i class="fas fa-clock"></i> <?=date('d/m/Y H:i',strtotime($p['created_at']))?></span>
</div>
<div style="display:flex;gap:8px;flex-shrink:0">
<a href="solicitacoes.php?aprovar=<?=$p['id']?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Aprovar</a>
<button onclick="Swal.fire({title:'Rejeitar?',icon:'warning',showCancelButton:true,confirmButtonColor:'#dc2626',confirmButtonText:'Rejeitar'}).then(r=>{if(r.isConfirmed)location='solicitacoes.php?rejeitar=<?=$p['id']?>'})" class="btn btn-danger btn-sm"><i class="fas fa-times"></i> Rejeitar</button>
</div></div>
<?php endforeach;?></div><?php endif;?>
</div>
<?php renderScripts();?></body></html>
