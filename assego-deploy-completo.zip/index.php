<?php
require_once 'layout.php';
if(!$evento_atual){/* no event */}

$stats=['total'=>0,'pendentes'=>0,'novos'=>0];
if($evento_atual){
    $eid=$evento_atual['id'];
    $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=1 AND evento_id=?");$s->execute([$eid]);$stats['total']=(int)$s->fetchColumn();
    $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=0 AND evento_id=?");$s->execute([$eid]);$stats['pendentes']=(int)$s->fetchColumn();
    $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=1 AND evento_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)");$s->execute([$eid]);$stats['novos']=(int)$s->fetchColumn();
}

$page=max(1,(int)($_GET['page']??1));$per_page=(int)($_GET['per_page']??10);$offset=($page-1)*$per_page;$search=$_GET['search']??'';
$total_records=0;$lista=[];
if($evento_atual){
    $eid=$evento_atual['id'];$where="WHERE p.aprovado=1 AND p.evento_id=?";$params=[$eid];
    if($search){$where.=" AND (p.nome LIKE ? OR p.whatsapp LIKE ? OR p.instagram LIKE ? OR p.campos_extras LIKE ?)";$l="%$search%";$params=array_merge($params,[$l,$l,$l,$l]);}
    $s=$pdo->prepare("SELECT COUNT(*) FROM participantes p $where");$s->execute($params);$total_records=(int)$s->fetchColumn();$total_pages=ceil($total_records/$per_page);
    $s=$pdo->prepare("SELECT p.* FROM participantes p $where ORDER BY p.nome LIMIT $per_page OFFSET $offset");$s->execute($params);$lista=$s->fetchAll();
}
$campos_extras=[];
if($evento_atual&&!empty($evento_atual['campos_extras']))$campos_extras=json_decode($evento_atual['campos_extras'],true)?:[];

$slug_ev=$evento_atual['slug']??null;
$base=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']==='on'?"https":"http")."://".$_SERVER['HTTP_HOST'].dirname($_SERVER['SCRIPT_NAME']).'/';
$link_cadastro=$base."inscricao.php?evento=".($slug_ev?:($evento_atual['id']??''));

if(isset($_GET['message']))echo "<script>document.addEventListener('DOMContentLoaded',()=>Swal.fire({icon:'success',title:'Sucesso!',text:'".addslashes($_GET['message'])."',timer:3000,showConfirmButton:false}));</script>";
?>
<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>ASSEGO Eventos</title><?php renderCSS();?></head><body>
<?php renderHeader('index');?>

<?php if(!$evento_atual):?>
<div class="no-evento-alert"><i class="fas fa-calendar-times" style="font-size:48px;color:#dbeafe;display:block;margin-bottom:16px"></i><h3 style="color:var(--primary)">Nenhum evento disponível</h3>
<p style="color:var(--gray)"><?=isAdmin()?'Crie um evento. <br><a href="eventos.php?action=add" class="btn btn-primary mt-3"><i class="fas fa-plus-circle"></i> Criar Evento</a>':'Solicite acesso ao administrador.'?></p></div>
<?php else:?>

<div class="stats-container">
    <div class="stat-card"><div class="stat-header"><div><div class="stat-value"><?=$stats['total']?></div><div class="stat-label">Cadastrados</div></div><div class="stat-icon"><i class="fas fa-users"></i></div></div></div>
    <div class="stat-card"><div class="stat-header"><div><div class="stat-value"><?=$stats['novos']?></div><div class="stat-label">Novos (30 dias)</div></div><div class="stat-icon" style="background:linear-gradient(135deg,#0284c7,#0ea5e9)"><i class="fas fa-user-plus"></i></div></div></div>
    <div class="stat-card"><div class="stat-header"><div><div class="stat-value"><?=$stats['pendentes']?></div><div class="stat-label">Pendentes</div></div><div class="stat-icon" style="background:linear-gradient(135deg,#d97706,#f59e0b)"><i class="fas fa-user-clock"></i></div></div></div>
</div>

<div style="background:white;padding:20px 24px;margin:0 24px 20px;border-radius:16px;box-shadow:var(--shadow-md);border:1px solid #dbeafe">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:12px">
        <h3 style="color:var(--primary);font-size:18px;font-weight:600;margin:0"><i class="fas fa-filter"></i> <?=htmlspecialchars($evento_atual['nome'])?></h3>
        <div class="d-flex gap-2 flex-wrap">
            <a href="participantes.php?action=add" class="btn btn-success btn-sm"><i class="fas fa-plus-circle"></i> Novo</a>
            <button class="btn btn-sm" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);color:white;border:none" data-bs-toggle="modal" data-bs-target="#modalLink"><i class="fas fa-share-alt"></i> Link</button>
            <a href="export.php?format=excel" class="btn btn-info btn-sm"><i class="fas fa-download"></i> Excel</a>
        </div>
    </div>
    <form method="GET" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end">
        <div style="flex:1;min-width:200px"><input type="text" name="search" class="form-control" placeholder="Buscar nome, WhatsApp, CPF..." value="<?=htmlspecialchars($search)?>"></div>
        <select name="per_page" class="form-select" style="width:auto" onchange="this.form.submit()">
            <option value="10" <?=$per_page==10?'selected':''?>>10</option><option value="25" <?=$per_page==25?'selected':''?>>25</option><option value="50" <?=$per_page==50?'selected':''?>>50</option><option value="100" <?=$per_page==100?'selected':''?>>100</option>
        </select>
        <button class="btn btn-primary"><i class="fas fa-search"></i> Buscar</button>
    </form>
</div>

<div class="table-container">
<div class="table-header"><h3 class="table-title">Cadastrados</h3><span style="color:var(--gray)"><?=$total_records?> registros</span></div>
<div style="overflow-x:auto"><table class="table"><thead><tr>
<th>Nome</th><th>WhatsApp</th><th>Instagram</th>
<?php foreach(array_slice($campos_extras,0,2) as $ce):?><th><?=htmlspecialchars($ce['label'])?></th><?php endforeach;?>
<th class="text-center">Ações</th>
</tr></thead><tbody>
<?php if(!empty($lista)):foreach($lista as $p):$ex=json_decode($p['campos_extras']??'{}',true)?:[];?>
<tr>
<td class="fw-semibold"><?=htmlspecialchars(strtoupper($p['nome']))?></td>
<td><?=htmlspecialchars($p['whatsapp']??'-')?></td>
<td><?=!empty($p['instagram'])?'@'.htmlspecialchars(ltrim($p['instagram'],'@')):'-'?></td>
<?php foreach(array_slice($campos_extras,0,2) as $ce):?><td><?=htmlspecialchars($ex[$ce['nome']]??'-')?></td><?php endforeach;?>
<td><div class="action-buttons">
<a href="participante_view.php?id=<?=$p['id']?>" class="btn-action view"><i class="fas fa-eye"></i></a>
<a href="participantes.php?action=edit&id=<?=$p['id']?>" class="btn-action edit"><i class="fas fa-edit"></i></a>
<button onclick="Swal.fire({title:'Excluir?',icon:'warning',showCancelButton:true,confirmButtonColor:'#dc2626',confirmButtonText:'Excluir'}).then(r=>{if(r.isConfirmed)location='participantes.php?action=delete&id=<?=$p['id']?>'})" class="btn-action delete"><i class="fas fa-trash"></i></button>
</div></td></tr>
<?php endforeach;else:?><tr><td colspan="<?=4+count(array_slice($campos_extras,0,2))?>"><div class="empty-state"><div class="empty-icon"><i class="fas fa-users-slash"></i></div><p class="empty-text">Nenhum cadastrado</p><a href="participantes.php?action=add" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Cadastrar</a></div></td></tr><?php endif;?>
</tbody></table></div>
<?php if(isset($total_pages)&&$total_pages>1):?>
<div class="pagination-container"><div style="color:var(--gray);font-size:14px">Mostrando <?=min($offset+1,$total_records)?> a <?=min($offset+$per_page,$total_records)?> de <?=$total_records?></div>
<nav><ul class="pagination"><?php for($i=max(1,$page-2);$i<=min($total_pages,$page+2);$i++):?><li class="page-item <?=$i==$page?'active':''?>"><a class="page-link" href="?page=<?=$i?><?=$search?"&search=$search":''?>"><?=$i?></a></li><?php endfor;?></ul></nav></div>
<?php endif;?>
</div>

<!-- Modal Link -->
<div class="modal fade" id="modalLink" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content" style="border-radius:16px;border:none">
<div class="modal-header" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);color:white;border-radius:16px 16px 0 0"><h5 class="modal-title"><i class="fas fa-link"></i> Link de Cadastro</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<div class="modal-body p-4 text-center">
<p class="text-muted small">Envie para as pessoas se cadastrarem no evento</p>
<div class="input-group mb-3"><input type="text" class="form-control bg-light" id="linkInput" value="<?=$link_cadastro?>" readonly><button class="btn btn-primary" onclick="navigator.clipboard.writeText(document.getElementById('linkInput').value).then(()=>Swal.fire({icon:'success',title:'Copiado!',timer:1500,showConfirmButton:false}))"><i class="fas fa-copy"></i></button></div>
</div></div></div></div>
<?php endif;?>
<?php renderScripts();?></body></html>
