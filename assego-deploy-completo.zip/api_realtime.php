<?php
if(session_status()===PHP_SESSION_NONE) session_start();
require_once 'config.php'; checkLogin();
header('Content-Type: application/json'); header('Cache-Control: no-cache');
$pdo=getConnection(); $action=$_GET['action']??'stats'; $eid=(int)($_GET['evento_id']??($_SESSION['evento_atual']??0));
if(!$eid){echo json_encode(['error'=>'no_event']);exit();}
try{
    switch($action){
        case 'stats':
            $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=1 AND (ativo IS NULL OR ativo=1) AND evento_id=?");$s->execute([$eid]);$total=(int)$s->fetchColumn();
            $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=1 AND ativo=0 AND evento_id=?");$s->execute([$eid]);$inat=(int)$s->fetchColumn();
            $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=1 AND (ativo IS NULL OR ativo=1) AND evento_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)");$s->execute([$eid]);$novos=(int)$s->fetchColumn();
            $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=0 AND evento_id=?");$s->execute([$eid]);$pend=(int)$s->fetchColumn();
            echo json_encode(['total'=>$total,'inativos'=>$inat,'novos'=>$novos,'pendentes'=>$pend]);break;
        case 'badge':
            $s=$pdo->prepare("SELECT COUNT(*) FROM participantes WHERE aprovado=0 AND evento_id=?");$s->execute([$eid]);
            echo json_encode(['pendentes'=>(int)$s->fetchColumn()]);break;
        default: echo json_encode(['error'=>'invalid']);
    }
}catch(Exception $e){http_response_code(500);echo json_encode(['error'=>$e->getMessage()]);}
?>
